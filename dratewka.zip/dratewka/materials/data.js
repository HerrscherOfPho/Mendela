export const data = {
    11:{
        "note":"You are inside a brimstone mine",
        "color":"rgb(235,211,64)"
    },
    12:{
        "note":"You are at the entrance to the mine",
        "color":"rgb(89,93,87)"
    },
    13:{
        "note":"A hill",
        "color":"rgb(117,237,243)"
    },
    14:{
        "note":"Some bushes",
        "color":"rgb(202,230,51)"
    },
    15:{
        "note":"An old deserted hut",
        "color":"rgb(220,204,61)"
    },
    16:{
        "note":"The edge of a forest",
        "color":"rgb(167,245,63)"
    },
    17:{
        "note":"A dark forest",
        "color":"rgb(140,253,99)"
    },
    21:{
        "note":"A man nearby making tar",
        "color":"rgb(255,190,99)"
    },
    22:{
        "note":"A timber yard",
        "color":"rgb(255,190,99)"
    },
    23:{
        "note":"You are by a roadside shrine",
        "color":"rgb(167,245,63)"
    },
    24:{
        "note":"You are by a small chapel",
        "color":"rgb(212,229,36)"
    },
    25:{
        "note":"You are on a road leading to a wood",
        "color":"rgb(167,245,63)"
    },
    26:{
        "note":"You are in a forest",
        "color":"rgb(167,245,63)"
    },
    27:{
        "note":"You are in a deep forest",
        "color":"rgb(140,253,99)"
    },
    31:{
        "note":"You are by the Vistula River",
        "color":"rgb(122,232,252)"
    },
    32:{
        "note":"You are by the Vistula River",
        "color":"rgb(140,214,255)"
    },
    33:{
        "note":"You are on a bridge over river",
        "color":"rgb(108,181,242)"
    },
    34:{
        "note":"You are by the old tavern",
        "color":"rgb(255,189,117)"
    },
    35:{
        "note":"You are at the town's end",
        "color":"rgb(255,190,99)"
    },
    36:{
        "note":"You are in a butcher's shop",
        "color":"rgb(255,188,102)"
    },
    37:{
        "note":"You are in a cooper's house",
        "color":"rgb(255,188,102)"
    },
    41:{
        "note":"You are in the Wawel Castle",
        "color":"rgb(255,176,141)"
    },
    42:{
        "note":"You are inside a dragon's cave",
        "color":"rgb(198,205,193)"
    },
    43:{
        "note":"A perfect place to set a trap",
        "color":"rgb(255,176,141)"
    },
    44:{
        "note":"You are by the water mill",
        "color":"rgb(255,190,99)"
    },
    45:{
        "note":"You are at a main crossroad",
        "color":"rgb(255,190,99)"
    },
    46:{
        "note":"You are on a town street",
        "color":"rgb(255,190,99)"
    },
    47:{
        "note":"You are in a frontyard of your house",
        "color":"rgb(255,190,99)"
    },
    54:{
        "note":"You are by a swift stream",
        "color":"rgb(108,181,242)"
    },
    55:{
        "note":"You are on a street leading forest",
        "color":"rgb(255,190,99)"
    },
    56:{
        "note":"You are in a woodcutter's backyard",
        "color":"rgb(255,190,99)"
    },
    57:{
        "note":"You are in a shoemaker's house",
        "color":"rgb(254,194,97)"
    },
    64:{
        "note":"You are in a bleak funeral house",
        "color":"rgb(254,194,97)"
    },
    65:{
        "note":"You are on a path leading to the wood",
        "color":"rgb(167,245,63)"
    },
    66:{
        "note":"You are at the edge of a forest",
        "color":"rgb(167,245,63)"
    },
    67:{
        "note":"You are in a deep forest",
        "color":"rgb(140,253,99)"
    }
}