import {map} from "./materials/map.js"
import {data} from "./materials/data.js"

//location variables
let currentlocation = "47"
let currenty = currentlocation.substring(0,1)
let currentx = currentlocation.substring(1)

//options variables

reload();

function reload(){
    let directions=[]
    document.getElementById("moving").innerText = ""
    let locationtext = data[currentlocation].note
    document.getElementById("location").innerText = locationtext
    let locationimagesource = "./materials/img/"+currentlocation+".gif"
    document.getElementById("locationimg").src = locationimagesource
    let locationbackgroundcolor = data[currentlocation].color
    document.getElementById("locationimg").style.backgroundColor = locationbackgroundcolor

    if(map[currentlocation].NORTH){
        directions.push("NORTH")
    }
    if(map[currentlocation].EAST){
        directions.push("EAST")
    }
    if(map[currentlocation].SOUTH){
        directions.push("SOUTH")
    }
    if(map[currentlocation].WEST){
        directions.push("WEST")
    }
    let directionstext = String(directions)
    let itemsseentext = "You see "
    let itemcarriedtext = "nothing"
    document.getElementById("directions").innerText = ("You can go " + directionstext)
    document.getElementById("itemsseen").innerText = itemsseentext
    document.getElementById('itemscarried').innerText = ("You are carrying " + itemcarriedtext)
}

let command = ""
document.getElementById("commands").onkeydown=commanded
function commanded(event){
    //jeśli nie ma takiego kierunku wyświetl default, nie wiem gdzie dać warunek
    if (event.key === "Enter"){
        command = document.getElementById("commands").value
        switch (command){
            case "N":
            case "NORTH":
                goingnorth();
                break;
            case "E":
            case "EAST":
                goingeast();
                break;
            case "S":
            case "SOUTH":
                goingsouth();
                break;
            case "W":
            case "WEST":
                goingwest();
                break;
            default:
                document.getElementById("moving").innerText = "You can't go that way"
                setTimeout(() => {
                    document.getElementById("moving").innerText = ""
                  }, "1000");
        }
        // if(map[currentlocation].NORTH){
        //     if (command=="N"||command=="NORTH"){
        //         goingnorth();
        //     }
        // }
        // if(map[currentlocation].EAST){
        //     if(command=="E"||command=="EAST"){
        //         goingeast();
        //     }
        // }
        // if(map[currentlocation].SOUTH){
        //     if (command=="S"||command=="SOUTH"){
        //         goingsouth();
        //     }
        // }
        // if(map[currentlocation].WEST){
        //     if (command=="W"||command=="WEST"){
        //         goingwest();
        //     }
        // }
        document.getElementById("commands").value = ""
    }

}

function goingnorth(){
    console.log("moved north");
    currenty = currenty - 1
    currentlocation = "" + currenty + currentx
    document.getElementById("moving").innerText = "You are going north..."
    setTimeout(() => {
        reload();
      }, "1000");
}
function goingeast(){
    console.log("moved east")
    currentx = currentx + 1
    currentlocation = "" + currenty + currentx
    document.getElementById("moving").innerText = "You are going east..."
    setTimeout(() => {
        reload();
      }, "1000");
}
function goingsouth(){
    console.log("moved south")
    currenty = currenty + 1
    currentlocation = "" + currenty + currentx
    document.getElementById("moving").innerText = "You are going south..."
    setTimeout(() => {
        reload();
      }, "1000");
}
function goingwest(){
    console.log("moved west")
    currentx = currentx - 1
    currentlocation = "" + currenty + currentx
    document.getElementById("moving").innerText = "You are going west..."
    setTimeout(() => {
        reload();
      }, "1000");
}
