import {map} from "./materials/map.js"

//location variables
let currentlocation = 47

let locationtext = "You are in a frontyard of your house"
document.getElementById("location").innerText = locationtext
let locationimagesource = "./materials/img/"+currentlocation+".gif"
document.getElementById("locationimg").src = locationimagesource
let locationbackgroundcolor = "rgb(255,190,99)"
document.getElementById("locationimg").style.backgroundColor = locationbackgroundcolor

//options variables
let directionsimport = map[currentlocation]
let directions=[]
if(map[currentlocation].NORTH){
    directions.push("NORTH")
}
if(map[currentlocation].EAST){
    directions.push("EAST")
}
if(map[currentlocation].SOUTH){
    directions.push("SOUTH")
}
if(map[currentlocation].WEST){
    directions.push("WEST")
}
let directionstext = String(directions)
let itemsseentext = "You see "
let itemcarriedtext = "nothing"
document.getElementById("directions").innerText = ("You can go " + directionstext)
document.getElementById("itemsseen").innerText = itemsseentext
document.getElementById('itemscarried').innerText = ("You are carrying " + itemcarriedtext)

let command = ""
document.getElementById("commands").onkeydown=commanded
function commanded(event){
    if (event.key === "Enter"){
        command = document.getElementById("commands").value
        if (command=="N"||command=="NORTH"){
            goingnorth();
        }
        if(command=="E"||command=="EAST"){
            goingeast();
        }
        if (command=="S"||command=="SOUTH"){
            goingsouth();
        }
        if (command=="W"||command=="WEST"){
            goingwest();
        }
        document.getElementById("commands").value = ""
    }

}

function goingnorth(){
    console.log("moved north")
}
function goingeast(){
    console.log("moved east")
}
function goingsouth(){
    console.log("moved south")
}
function goingwest(){
    console.log("moved west")
}
