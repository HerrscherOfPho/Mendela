export const data = {
    11:{
        "note":"You are inside a brimstone mine",
        "color":"rgb(235,211,64)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    12:{
        "note":"You are at the entrance to the mine",
        "color":"rgb(89,93,87)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    13:{
        "note":"A hill",
        "color":"rgb(117,237,243)",
        "item":{
            "flag":[1],
            "name":["a STONE"]
        }
    },
    14:{
        "note":"Some bushes",
        "color":"rgb(202,230,51)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    15:{
        "note":"An old deserted hut",
        "color":"rgb(220,204,61)",
        "item":{
            "flag":1,
            "name":"a BUCKET"
        }
    },
    16:{
        "note":"The edge of a forest",
        "color":"rgb(167,245,63)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    17:{
        "note":"A dark forest",
        "color":"rgb(140,253,99)",
        "item":{
            "flag":[1],
            "name":["MUSHROOMS"]
        }
    },
    21:{
        "note":"A man nearby making tar",
        "color":"rgb(255,190,99)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    22:{
        "note":"A timber yard",
        "color":"rgb(255,190,99)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    23:{
        "note":"You are by a roadside shrine",
        "color":"rgb(167,245,63)",
        "item":{
            "flag":[1],
            "name":["a KEY"]
        }
    },
    24:{
        "note":"You are by a small chapel",
        "color":"rgb(212,229,36)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    25:{
        "note":"You are on a road leading to a wood",
        "color":"rgb(167,245,63)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    26:{
        "note":"You are in a forest",
        "color":"rgb(167,245,63)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    27:{
        "note":"You are in a deep forest",
        "color":"rgb(140,253,99)",
        "item":{
            "flag":[1],
            "name":["BERRIES"]
        }
    },
    31:{
        "note":"You are by the Vistula River",
        "color":"rgb(122,232,252)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    32:{
        "note":"You are by the Vistula River",
        "color":"rgb(140,214,255)",
        "item":{
            "flag":[1],
            "name":["a FISH"]
        }
    },
    33:{
        "note":"You are on a bridge over river",
        "color":"rgb(108,181,242)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    34:{
        "note":"You are by the old tavern",
        "color":"rgb(255,189,117)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    35:{
        "note":"You are at the town's end",
        "color":"rgb(255,190,99)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    36:{
        "note":"You are in a butcher's shop",
        "color":"rgb(255,188,102)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    37:{
        "note":"You are in a cooper's house",
        "color":"rgb(255,188,102)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    41:{
        "note":"You are in the Wawel Castle",
        "color":"rgb(255,176,141)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    42:{
        "note":"You are inside a dragon's cave",
        "color":"rgb(198,205,193)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    43:{
        "note":"A perfect place to set a trap",
        "color":"rgb(255,176,141)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    44:{
        "note":"You are by the water mill",
        "color":"rgb(255,190,99)",
        "item":{
            "flag":[1],
            "name":["a BAG"]
        }
    },
    45:{
        "note":"You are at a main crossroad",
        "color":"rgb(255,190,99)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    46:{
        "note":"You are on a town street",
        "color":"rgb(255,190,99)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    47:{
        "note":"You are in a frontyard of your house",
        "color":"rgb(255,190,99)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    54:{
        "note":"You are by a swift stream",
        "color":"rgb(108,181,242)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    55:{
        "note":"You are on a street leading forest",
        "color":"rgb(255,190,99)",
        "item":{
            "flag":[1],
            "name":["a KNIFE"]
        }
    },
    56:{
        "note":"You are in a woodcutter's backyard",
        "color":"rgb(255,190,99)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    57:{
        "note":"You are in a shoemaker's house",
        "color":"rgb(254,194,97)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    64:{
        "note":"You are in a bleak funeral house",
        "color":"rgb(254,194,97)",
        "item":{
            "flag":[1],
            "name":["a SPADE"]
        }
    },
    65:{
        "note":"You are on a path leading to the wood",
        "color":"rgb(167,245,63)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    66:{
        "note":"You are at the edge of a forest",
        "color":"rgb(167,245,63)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    },
    67:{
        "note":"You are in a deep forest",
        "color":"rgb(140,253,99)",
        "item":{
            "flag":[0],
            "name":["nothing"]
        }
    }
}