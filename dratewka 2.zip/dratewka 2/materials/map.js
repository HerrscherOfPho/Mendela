
export const map = {
    11:{
        "NORTH": false, "EAST": true, "SOUTH": false, "WEST": false
    },
    12:{
        "NORTH": false, "EAST": true, "SOUTH": false, "WEST": true
    },
    13:{
        "NORTH": false, "EAST": true, "SOUTH": true, "WEST": true
    },
    14:{
        "NORTH": false, "EAST": true, "SOUTH": false, "WEST": true
    },
    15:{
        "NORTH": false, "EAST": true, "SOUTH": false, "WEST": true
    },
    16:{
        "NORTH": false, "EAST": true, "SOUTH": false, "WEST": true
    },
    17:{
        "NORTH": false, "EAST": false, "SOUTH": true, "WEST": true
    },
    21:{
        "NORTH": false, "EAST": true, "SOUTH": true, "WEST": false
    },
    22:{
        "NORTH": false, "EAST": true, "SOUTH": true, "WEST": true
    },
    23:{
        "NORTH": true, "EAST": true, "SOUTH": true, "WEST": true
    },
    24:{
        "NORTH": false, "EAST": true, "SOUTH": false, "WEST": true
    },
    25:{
        "NORTH": false, "EAST": true, "SOUTH": true, "WEST": true
    },
    26:{
        "NORTH": false, "EAST": true, "SOUTH": false, "WEST": true
    },
    27:{
        "NORTH": true, "EAST": false, "SOUTH": false, "WEST": true
    },
    31:{
        "NORTH": true, "EAST": true, "SOUTH": false, "WEST": false
    },
    32:{
        "NORTH": true, "EAST": false, "SOUTH": false, "WEST": true
    },
    33:{
        "NORTH": true, "EAST": false, "SOUTH": true, "WEST": false
    },
    34:{
        "NORTH": false, "EAST": true, "SOUTH": false, "WEST": false
    },
    35:{
        "NORTH": true, "EAST": true, "SOUTH": true, "WEST": false
    },
    36:{
        "NORTH": false, "EAST": false, "SOUTH": true, "WEST": false
    },
    37:{
        "NORTH": false, "EAST": false, "SOUTH": true, "WEST": false
    },
    41:{
        "NORTH": false, "EAST": false, "SOUTH": false, "WEST": true
    },
    42:{
        "NORTH": false, "EAST": true, "SOUTH": false, "WEST": true
    },
    43:{
        "NORTH": true, "EAST": false, "SOUTH": false, "WEST": true
    },
    44:{
        "NORTH": false, "EAST": true, "SOUTH": false, "WEST": false
    },
    45:{
        "NORTH": true, "EAST": true, "SOUTH": true, "WEST": true
    },
    46:{
        "NORTH": true, "EAST": true, "SOUTH": false, "WEST": true
    },
    47:{
        "NORTH": true, "EAST": false, "SOUTH": true, "WEST": true
    },
    54:{
        "NORTH": false, "EAST": true, "SOUTH": false, "WEST": false
    },
    55:{
        "NORTH": true, "EAST": false, "SOUTH": true, "WEST": true
    },
    56:{
        "NORTH": false, "EAST": false, "SOUTH": true, "WEST": false
    },
    57:{
        "NORTH": true, "EAST": false, "SOUTH": false, "WEST": false
    },
    64:{
        "NORTH": false, "EAST": true, "SOUTH": false, "WEST": false
    },
    65:{
        "NORTH": true, "EAST": true, "SOUTH": false, "WEST": true
    },
    66:{
        "NORTH": true, "EAST": true, "SOUTH": false, "WEST": true
    },
    67:{
        "NORTH": false, "EAST": false, "SOUTH": false, "WEST": true
    }
}
