import {map} from "./materials/map.js"
import {data} from "./materials/data.js"

//location variables
let currentlocation = "47"
let currenty = parseInt(currentlocation.substring(0,1))
let currentx = parseInt(currentlocation.substring(1))

let inventory = {"name":"nothing", "flag": 0}
//options variables

reload();

function reload(){
    console.log(currentlocation)
    console.log(data[currentlocation].item.name.length)
    let directions=[]
    document.getElementById("moving").innerText = ""
    let locationtext = data[currentlocation].note
    document.getElementById("location").innerText = locationtext
    let locationimagesource = "./materials/img/"+currentlocation+".gif"
    document.getElementById("locationimg").src = locationimagesource
    let locationbackgroundcolor = data[currentlocation].color
    document.getElementById("locationimg").style.backgroundColor = locationbackgroundcolor

    if(map[currentlocation].NORTH){
        directions.push("NORTH")
    }
    if(map[currentlocation].EAST){
        directions.push("EAST")
    }
    if(map[currentlocation].SOUTH){
        directions.push("SOUTH")
    }
    if(map[currentlocation].WEST){
        directions.push("WEST")
    }

    let itemsseen = data[currentlocation].item.name
    let directionstext = String(directions)
    let itemcarriedtext = inventory.name
    document.getElementById("directions").innerText = ("You can go " + directionstext)
    document.getElementById("itemsseen").innerText = ("You can see " + itemsseen)
    document.getElementById('itemscarried').innerText = ("You are carrying " + itemcarriedtext)
}

let command = ""
document.getElementById("commands").onkeydown=commanded
function commanded(event){
    //jeśli nie ma takiego kierunku wyświetl default, nie wiem gdzie dać warunek
    if (event.key === "Enter"){
        command = document.getElementById("commands").value
        if(map[currentlocation].NORTH){
            if (command=="N"||command=="NORTH"){
                goingnorth();
            }
        }
        if(map[currentlocation].EAST){
            if(command=="E"||command=="EAST"){
                goingeast();
            }
        }
        if(map[currentlocation].SOUTH){
            if (command=="S"||command=="SOUTH"){
                goingsouth();
            }
        }
        if(map[currentlocation].WEST){
            if (command=="W"||command=="WEST"){
                goingwest();
            }
        }
        if(data[currentlocation].item.flag[0] == 1){
            if(command=="T 1"||command=="TAKE 1"){
                takeitem1();
            }
        }
        if(data[currentlocation].item.flag[1] == 1){
            if(command=="T 2"||command=="TAKE 2"){
                takeitem2();
            }
        }
        if(data[currentlocation].item.flag[2] == 1){
            if(command=="T 3"||command=="TAKE 3"){
                takeitem3();
            }
        }
        if(inventory.flag == 1 && data[currentlocation].item.name.length < 3){
            if(command=="D"||command=="DROP"){
                dropitem();
            }
        }
        document.getElementById("commands").value = ""
    }

}

function goingnorth(){
    console.log("moved north");
    currenty = currenty - 1
    currentlocation = "" + currenty + currentx
    document.getElementById("moving").innerText = "You are going north..."
    setTimeout(() => {
        reload();
      }, "100");
}
function goingeast(){
    console.log("moved east")
    currentx = currentx + 1
    currentlocation = "" + currenty + currentx
    document.getElementById("moving").innerText = "You are going east..."
    setTimeout(() => {
        reload();
      }, "100");
}
function goingsouth(){
    console.log("moved south")
    currenty = currenty + 1
    currentlocation = "" + currenty + currentx
    document.getElementById("moving").innerText = "You are going south..."
    setTimeout(() => {
        reload();
      }, "100");
}
function goingwest(){
    console.log("moved west")
    currentx = currentx - 1
    currentlocation = "" + currenty + currentx
    document.getElementById("moving").innerText = "You are going west..."
    setTimeout(() => {
        reload();
      }, "100");
}
function takeitem1(){
    console.log("took "+data[currentlocation].item.name[0])
    inventory.name = String(data[currentlocation].item.name[0])
    inventory.flag = data[currentlocation].item.flag[0]
    if(data[currentlocation].item.name.length == 1){
        data[currentlocation].item.name[0] = "nothing"
        data[currentlocation].item.flag[0] = 0
    }else{
        data[currentlocation].item.name.splice(0, 1)
        data[currentlocation].item.flag.splice(0, 1)
    }
    document.getElementById("moving").innerText = "You are taking "+inventory.name+"..."
    setTimeout(() => {
        reload();
      }, "1000");
}
function takeitem2(){
    console.log("took "+data[currentlocation].item.name[1])
    inventory.name = String(data[currentlocation].item.name[1])
    inventory.flag = data[currentlocation].item.flag[1]
    data[currentlocation].item.name.splice(1,1)
    data[currentlocation].item.flag.splice(1,1)
    document.getElementById("moving").innerText = "You are taking "+inventory.name+"..."
    setTimeout(() => {
        reload();
      }, "1000");
}
function takeitem3(){
    console.log("took "+data[currentlocation].item.name[2])
    inventory.name = String(data[currentlocation].item.name[2])
    inventory.flag = data[currentlocation].item.flag[2]
    data[currentlocation].item.name.splice(2,1)
    data[currentlocation].item.flag.splice(2,1)
    document.getElementById("moving").innerText = "You are taking "+inventory.name+"..."
    setTimeout(() => {
        reload();
      }, "1000");
}
function dropitem(){
    console.log("dropped "+inventory.name)
    if(data[currentlocation].item.name[0] != "nothing"){
        data[currentlocation].item.name.push(inventory.name)
        data[currentlocation].item.flag.push(inventory.flag)
    }else{
        data[currentlocation].item.name[0] = inventory.name
        data[currentlocation].item.flag[0] = inventory.flag
    }
    inventory.name = "nothing"
    inventory.flag = 0
    reload();
}

//aktualna sytuacja:
// komunikaty na dropy i w ogóle, bo się robią za kazdym razem jak cos upuscisz