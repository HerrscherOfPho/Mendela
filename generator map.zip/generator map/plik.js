for (let j = 0; j < 40; j++) {
    const itemki = document.getElementById("itemki");
    const rowit = document.createElement("tr");
    itemki === null || itemki === void 0 ? void 0 : itemki.appendChild(rowit);
    for (let i = 0; i < 16; i++) {
        const item = document.createElement("td");
        item.classList.add('item');
        item.addEventListener('click', function () {
            let thisitem = this;
            let zaznaczonyitem = thisitem.outerHTML;
            zaznaczonyitem = zaznaczonyitem.replace('<td class=\"item\" id=\"', '');
            zaznaczonyitem = zaznaczonyitem.replace('\"></td>', '');
            console.log(JSON.stringify(zaznaczonyitem));
        });
        item.id = (j.toString()) + (i.toString());
        rowit === null || rowit === void 0 ? void 0 : rowit.appendChild(item);
    }
}
for (let j = 0; j < 20; j++) {
    const plansza = document.getElementById("plansza");
    const row = document.createElement("tr");
    plansza === null || plansza === void 0 ? void 0 : plansza.appendChild(row);
    for (let i = 0; i < 32; i++) {
        const pole = document.createElement("td");
        pole.classList.add('pole');
        pole.id = (j.toString()) + (i.toString());
        row === null || row === void 0 ? void 0 : row.appendChild(pole);
    }
}
