for(let j = 0; j<40; j++){
    const itemki = document.getElementById("itemki")
    const rowit = document.createElement("tr")
    itemki?.appendChild(rowit)
    for(let i=0; i<16; i++){
        const item = document.createElement("td");
        item.classList.add('item');
        item.addEventListener('click', function(this: HTMLElement){
            let thisitem = this as HTMLElement;
            let zaznaczonyitem: string = thisitem.outerHTML;
            zaznaczonyitem = zaznaczonyitem.replace('<td class=\"item\" id=\"','')
            zaznaczonyitem = zaznaczonyitem.replace('\"></td>','')
            console.log(JSON.stringify(zaznaczonyitem))
        })
        item.id = (j.toString())+(i.toString())
        rowit?.appendChild(item);
        }
    }  

for(let j = 0; j<20; j++){
    const plansza = document.getElementById("plansza")
    const row = document.createElement("tr")
    plansza?.appendChild(row)
    for(let i=0; i<32; i++){
        const pole = document.createElement("td");
        pole.classList.add('pole');
        pole.id = (j.toString())+(i.toString())
        row?.appendChild(pole);
        }
    }               

