<?php
print_r('AaAAAAA');